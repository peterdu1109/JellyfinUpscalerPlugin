import { checkHardwareSupport } from "../backend/hardwareCheck";

function applyUpscaling(videoElement) {
    const support = checkHardwareSupport();
    console.log(`Upscaling enabled: ${support}`);
    // GPU-Shader or CPU-based scaling logic here
}

const videoElement = document.querySelector("video");
if (videoElement) {
    applyUpscaling(videoElement);
}
