export function checkHardwareSupport() {
    if (navigator.userAgent.includes("NVIDIA")) {
        return "NVIDIA RTX detected";
    } else if (navigator.userAgent.includes("Apple")) {
        return "Apple Metal available";
    } else {
        return "Software upscaling";
    }
}
