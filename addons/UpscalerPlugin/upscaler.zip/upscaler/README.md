This add-on enables video upscaling in Jellyfin, only on supported devices.

Dieses Add-on ermöglicht Upscaling für Videos in Jellyfin, nur auf unterstützten Geräten.

Installation
clone that Repository:
https://raw.githubusercontent.com/Kuschel-code/JellyfinUpscalerRepo/main/repo.json

Supported Operating Systems: Windows Mac OS Linux Android iOS TV