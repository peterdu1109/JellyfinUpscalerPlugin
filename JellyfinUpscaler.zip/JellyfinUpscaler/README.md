# Jellyfin Upscaler Add-on

This add-on enables video upscaling in Jellyfin, only on supported devices.

Dieses Add-on ermöglicht Upscaling für Videos in Jellyfin, nur auf unterstützten Geräten.

## Installation

1. Klone das Repository:
   ```bash
   git clone https://github.com/monyone/JellyfinUpscaler.git
   cd JellyfinUpscaler
