# 📥 Installation Guide - AI Upscaler Plugin v1.3.5

## 🚀 **Method 1: GitHub Repository Link (EASIEST FOR SERVERS)**

### **Why this method is best:**
- ✅ **Automatic updates** - Always get latest version
- ✅ **Version management** - Rollback if needed  
- ✅ **Easy for admins** - One-time setup
- ✅ **No manual downloads** - Everything automatic

### **Step-by-Step:**

1. **Open Jellyfin Admin Dashboard**
2. **Navigate to**: Plugins → Repositories → **Add Repository**
3. **Fill in**:
   ```
   Repository Name: AI Upscaler Plugin
   Repository URL: https://raw.githubusercontent.com/Kuschel-code/JellyfinUpscalerPlugin/main/manifest.json
   ```
4. **Save** and go to **Plugins → Catalog**
5. **Find "AI Upscaler Plugin"** and click **Install**
6. **Restart Jellyfin** when prompted

## 📦 **Method 2: Direct ZIP Download**

1. **Download**: [JellyfinUpscalerPlugin-v1.3.5-RealFeatures.zip](https://github.com/Kuschel-code/JellyfinUpscalerPlugin/releases/download/v1.3.5/JellyfinUpscalerPlugin-v1.3.5-RealFeatures.zip)
2. **Upload**: Admin Dashboard → Plugins → Upload Plugin
3. **Select** ZIP file and install
4. **Restart** Jellyfin server

## ✅ **Verification**

After installation, check:
- Plugin appears in **My Plugins** with version **1.3.5**
- **Quick Settings** button appears when playing videos
- API endpoint works: `http://your-server:8096/api/upscaler/hardware`

## 🐛 **Troubleshooting**

### **Repository URL not working?**
Make sure you use the **exact URL**:
```
https://raw.githubusercontent.com/Kuschel-code/JellyfinUpscalerPlugin/main/manifest.json
```

### **Plugin not appearing?**
- Check Jellyfin version (10.10.0+ required)
- Restart Jellyfin server completely
- Clear browser cache (Ctrl+F5)

### **JavaScript errors?**
- Disable ad blockers on Jellyfin domain
- Check browser console (F12) for error messages
- Ensure WebGL is enabled in browser

## 📞 **Need Help?**
- 🐛 [GitHub Issues](https://github.com/Kuschel-code/JellyfinUpscalerPlugin/issues)
- 📧 support@jellyfinupscaler.com
- 💬 Discord support server